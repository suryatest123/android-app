package com.example.allsetproject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;


import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    public void startSending(View view){
    	//ID : 2098762357
    	//Latitude
    	//Longitude
    	//Elevation
    	
        new LongOperationTask().execute();
    }
   
    public void stopSending(View view){
    	
    }
    
    private class LongOperationTask extends AsyncTask {

		@Override
		protected String doInBackground(Object... arg0) {
			// TODO Auto-generated method stub
			String id ="2098762357";
	        String lat = "1331";
	        String lon = "1331";
	        String elev = "1331";
	        
	        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
	        nameValuePairs.add(new BasicNameValuePair("ID", id));
	        nameValuePairs.add(new BasicNameValuePair("Latitude", lat));
	        nameValuePairs.add(new BasicNameValuePair("Longitude", lon));
	        nameValuePairs.add(new BasicNameValuePair("Elevation", elev));
	        
	        try{
	        	HttpClient httpclient = new DefaultHttpClient();
	        	System.out.println("1");
	        	
	        	HttpPost httppost = new HttpPost("http://visionsperipheral.com/form.php");
	        	httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs,"UTF-8"));
	        	System.out.println("Before namevaluepairs");
	        	for( int i=0; i<nameValuePairs.size();i++){
	        		System.out.println(nameValuePairs.get(i).getName()+ "  " + nameValuePairs.get(i).getValue() );
	        	}
	        	System.out.println("After Namevaluepairs");
	        	
	        	HttpResponse response = httpclient.execute(httppost);
	        	InputStreamReader is = new InputStreamReader(response.getEntity().getContent(),"iso-8859-1");
	        	BufferedReader reader = new BufferedReader(is,8);
	        	StringBuilder sb = new StringBuilder();
	            String line = null;
	            while ((line = reader.readLine()) != null) {
	                    sb.append(line + "\n");
	            }
	            is.close();
	     
	            System.out.println("final out " + sb.toString());
	        	System.out.println("4  " + response.getStatusLine());
	        }catch (Exception e){
	        	Log.e("log_tag", "Error:  "+e.toString());
	        }	
			
			return null;
		}
		
    }
}
